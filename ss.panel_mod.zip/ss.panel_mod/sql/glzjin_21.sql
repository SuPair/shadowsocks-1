DROP TABLE `smartline`, `ss_user_admin`;

ALTER TABLE `user`
  DROP `relay_enable`,
  DROP `relay_info`;