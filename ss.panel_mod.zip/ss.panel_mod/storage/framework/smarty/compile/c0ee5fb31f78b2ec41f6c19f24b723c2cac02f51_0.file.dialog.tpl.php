<?php
/* Smarty version 3.1.31, created on 2017-05-27 13:01:17
  from "/home/wwwroot/ss.panel/resources/views/material/dialog.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5929081d781335_43682433',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c0ee5fb31f78b2ec41f6c19f24b723c2cac02f51' => 
    array (
      0 => '/home/wwwroot/ss.panel/resources/views/material/dialog.tpl',
      1 => 1495860748,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5929081d781335_43682433 (Smarty_Internal_Template $_smarty_tpl) {
?>
<div aria-hidden="true" class="modal modal-va-middle fade" id="result" role="dialog" tabindex="-1">
	<div class="modal-dialog modal-xs">
		<div class="modal-content">
			<div class="modal-inner">
				<p class="h5 margin-top-sm text-black-hint" id="msg"></p>
			</div>
			<div class="modal-footer">
				<p class="text-right"><button class="btn btn-flat btn-brand-accent waves-attach" data-dismiss="modal" type="button" id="result_ok">知道了</button></p>
			</div>
		</div>
	</div>
</div><?php }
}
