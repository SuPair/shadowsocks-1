<?php
/* Smarty version 3.1.31, created on 2017-05-27 13:00:04
  from "/home/wwwroot/ss.panel/resources/views/material/footer.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_592907d4de0515_80581893',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '67d3a2565a66e75908c3def96dff49818d6f8397' => 
    array (
      0 => '/home/wwwroot/ss.panel/resources/views/material/footer.tpl',
      1 => 1495860748,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
    'file:analytics.tpl' => 1,
  ),
),false)) {
function content_592907d4de0515_80581893 (Smarty_Internal_Template $_smarty_tpl) {
?>
	<footer class="ui-footer">
		<div class="container">
			&copy; <?php echo $_smarty_tpl->tpl_vars['config']->value["appName"];?>
  <a href="/staff">STAFF</a> <?php if ($_smarty_tpl->tpl_vars['config']->value["enable_analytics_code"] == 'true') {
$_smarty_tpl->_subTemplateRender('file:analytics.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, $_smarty_tpl->cache_lifetime, array(), 0, false);
}?>
		</div>
	</footer>


	<!-- js -->
	<?php echo '<script'; ?>
 src="//cdn.staticfile.org/jquery/2.2.1/jquery.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="//static.geetest.com/static/tools/gt.js"><?php echo '</script'; ?>
>
	
	<?php echo '<script'; ?>
 src="/theme/material/js/base.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/theme/material/js/project.min.js"><?php echo '</script'; ?>
>
</body>
</html><?php }
}
